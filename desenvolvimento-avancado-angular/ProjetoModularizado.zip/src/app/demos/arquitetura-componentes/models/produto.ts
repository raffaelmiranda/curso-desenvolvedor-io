export interface Produto {
    id: number,
    nome: string,
    ativo: boolean,
    valor: number,
    imagem: string
  }