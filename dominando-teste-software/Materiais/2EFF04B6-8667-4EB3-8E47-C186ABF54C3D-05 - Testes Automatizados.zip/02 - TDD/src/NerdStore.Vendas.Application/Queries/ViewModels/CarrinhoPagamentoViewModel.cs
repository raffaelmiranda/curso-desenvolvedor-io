﻿namespace NerdStore.Vendas.Application.Queries.ViewModels
{
    public class CarrinhoPagamentoViewModel
    {
        public string NomeCartao { get; set; }
        public string NumeroCartao { get; set; }
        public string ExpiracaoCartao { get; set; }
        public string CvvCartao { get; set; }
    }
}