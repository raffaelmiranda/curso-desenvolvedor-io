namespace NerdStore.WebApp.MVC.Models
{
    public class LoginViewModel
    {
        public string Email { get; set; }

        public string Senha { get; set; }
    }
}