﻿namespace Demo
{
    public class Calculadora
    {
        public double Somar(double v1, double v2)
        {
            return v1 + v2;
        }

        public int Dividir(int v1, int v2)
        {
            return v1 / v2;
        }
    }
}