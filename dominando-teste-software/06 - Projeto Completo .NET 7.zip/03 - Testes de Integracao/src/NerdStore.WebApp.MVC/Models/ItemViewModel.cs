namespace NerdStore.WebApp.MVC.Models
{
    public class ItemViewModel
    {
        public Guid Id { get; set; }

        public int Quantidade { get; set; }
    }
}