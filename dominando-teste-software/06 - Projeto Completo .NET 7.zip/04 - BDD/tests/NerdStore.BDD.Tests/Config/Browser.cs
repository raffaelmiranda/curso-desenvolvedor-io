﻿namespace NerdStore.BDD.Tests.Config
{
    public enum Browser
    {
        Chrome,
        Firefox
    }
}

