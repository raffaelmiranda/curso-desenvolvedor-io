﻿namespace NerdStore.BDD.Tests.Usuario
{
    public class Usuario
    {
        public string Email { get; set; }
        public string Senha { get; set; }
    }
}