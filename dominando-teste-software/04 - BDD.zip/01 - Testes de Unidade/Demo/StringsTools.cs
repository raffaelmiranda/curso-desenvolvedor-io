﻿namespace Demo
{
    public class StringsTools
    {
        public string Unir(string nome, string sobrenome)
        {
            return $"{nome} {sobrenome}";
        }
    }
}